import re
import numpy as np
import networkx as nx
import rdkit
from rdkit import Chem
from rdkit import RDConfig
from rdkit.Chem import ChemicalFeatures
from torch.utils.data import DataLoader
import torch.utils.data as data
import os 
import torch
import time
import dgl
import dgl.function as fn
import torch 
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import multiprocessing
import shutil
import torch.utils.data as data
import six
import pdb
import nltk
import torch.nn.utils.rnn as rnn_utils

ATOMS = ['B',
 'Br',
 'C',
 'Cl',
 'Cu',
 'F',
 'Fe',
 'I',
 'K',
 'Li',
 'Mg',
 'N',
 'O',
 'P',
 'Pd',
 'Pt',
 'S',
 'Se',
 'Si',
 'Sn',
 'Zn']


EMB_ATOMS = ATOMS+['c','p'
 'n',
 'o',
 's',
 'se']


def extract_graph_feature(g, hydrogen = True):
    # node features
    h = []
    for n, d in list(g.nodes()(data=True)):
        is_atom = True
        try:
            a = d['a_type']
        except:
            is_atom = False
        if is_atom:
            h_t = []
            # Atom type (One-hot)
            h_t += [int(d['a_type'] == x) for x in ATOMS]
            # Atomic number
            h_t.append(d['a_num'])
            # Acceptor
            h_t.append(d['acceptor'])
            # Donor
            h_t.append(d['donor'])
            # Aromatic
            h_t.append(int(d['aromatic']))
            # Hybradization
            h_t += [int(d['hybridization'] == x) for x in [rdkit.Chem.rdchem.HybridizationType.SP, rdkit.Chem.rdchem.HybridizationType.SP2, rdkit.Chem.rdchem.HybridizationType.SP3]]
            # If number hydrogen is used as a
            if hydrogen:
                h_t.append(d['num_h'])

        else:
            h_t = [0]*29

        h.append(h_t)

    #edge features
    remove_edges = []
    e={}    
    for n1, n2, d in list(g.edges()(data=True)):
        e_t = []
        if d['b_type'] is None:
            remove_edges += [(n1, n2)]
        else:
            e_t += [int(d['b_type'] == x) for x in [rdkit.Chem.rdchem.BondType.SINGLE, rdkit.Chem.rdchem.BondType.DOUBLE,
                                                    rdkit.Chem.rdchem.BondType.TRIPLE, rdkit.Chem.rdchem.BondType.AROMATIC]]
        if e_t:
            e[(n1, n2)] = e_t
    for edg in remove_edges:
        g.remove_edge(*edg)

    return h, e



def collate_dgl(samples):
    # The input `samples` is a list of graphs
    batched_graph = dgl.batch(samples)
    
    return batched_graph
    

def collate_g(batch):

    batch_sizes = np.max(np.array([[len(input_b[1]), len(input_b[1][0]), len(input_b[2]),
                                len(list(input_b[2].values())[0])]
                                if input_b[2] else
                                [len(input_b[1]), len(input_b[1][0]), 0,0]
                                for (input_b, target_b) in batch]), axis=0)

    g = np.zeros((len(batch), batch_sizes[0], batch_sizes[0]))
    h = np.zeros((len(batch), batch_sizes[0], batch_sizes[1]))
    e = np.zeros((len(batch), batch_sizes[0], batch_sizes[0], batch_sizes[3]))

    target = np.zeros((len(batch), len(batch[0][1])))

    for i in range(len(batch)):

        num_nodes = len(batch[i][0][1])

        # Adjacency matrix
        g[i, 0:num_nodes, 0:num_nodes] = batch[i][0][0]
       
        # Node features
        h[i, 0:num_nodes, :] = batch[i][0][1]

        # Edges
        for edge in batch[i][0][2].keys():
            e[i, edge[0], edge[1], :] = batch[i][0][2][edge]
            e[i, edge[1], edge[0], :] = batch[i][0][2][edge]

        # Target
        target[i, :] = batch[i][1]

    g = torch.FloatTensor(g)
    h = torch.FloatTensor(h)
    e = torch.FloatTensor(e)
    target = torch.FloatTensor(target)

    return g, h, e, target


def gcn_emb(model, gs):
    batched_graph = dgl.batch(gs)
    batched_graph.to(torch.device('cuda:0'))
    return model(batched_graph, batched_graph.ndata['init_h'])



def need_emb(word, EMB_ATOMS):
    return word in EMB_ATOMS
        


def str2molgraph(rawstr, length):  # rawstr :tuple() e.g. ('<RX_6>', 'N', 'c', '1', 'n', 'c', '2', '[', 'n', 'H', ']', 'c', '(', 'C', 'C', 'C', 'c', '3', 'c', 's', 'c', '(', 'C', '(', '=', 'O', ')', 'O', ')', 'c', '3', ')', 'c', 'c', '2', 'c', '(', '=', 'O', ')', '[', 'n', 'H', ']', '1')    
    
    smiles = ''.join(rawstr[1:length])
    
    m = Chem.MolFromSmiles(smiles)

    g = nx.Graph()
    fdef_name = os.path.join(RDConfig.RDDataDir, 'BaseFeatures.fdef')
    factory = ChemicalFeatures.BuildFeatureFactory(fdef_name)
    feats = factory.GetFeaturesForMol(m)

    atom_true_index = {}
    atom_index = 0
    # Nodes
    for i in range(len(rawstr)):
        if not need_emb(rawstr[i], EMB_ATOMS):
            g.add_node(i)
           
        else:
            atom_true_index[atom_index] = i     # meanwhile, set a map dict to find the true index of atoms
            atom_i = m.GetAtomWithIdx(atom_index)
            atom_index += 1
            g.add_node(i, a_type=atom_i.GetSymbol(), a_num=atom_i.GetAtomicNum(), acceptor=0, donor=0,
        aromatic=atom_i.GetIsAromatic(), hybridization=atom_i.GetHybridization(), num_h=atom_i.GetTotalNumHs())
    

        
    # Donor and Acceptor properties
    for i in range(0, len(feats)):
        if feats[i].GetFamily() == 'Donor':
            node_list = feats[i].GetAtomIds()
            for j in node_list:
                g.node[atom_true_index[j]]['donor'] = 1
        elif feats[i].GetFamily() == 'Acceptor':
            node_list = feats[i].GetAtomIds()
 
            for j in node_list:
            
                g.node[atom_true_index[j]]['acceptor'] = 1
               
    #Edges
    for i in range(0, m.GetNumAtoms()):
        for j in range(0, m.GetNumAtoms()):
            e_ij = m.GetBondBetweenAtoms(i, j)
            if e_ij is not None:
                try:
                    g.add_edge(atom_true_index[i], atom_true_index[j], b_type=e_ij.GetBondType())
                except:
                    print(smiles)
                    print(m.GetNumAtoms()) 
                    print(atom_true_index)
                    input()

    return g


def str2graph(rawstr):
    g = str2molgraph(rawstr, len(rawstr))
    h, e = extract_graph_feature(g)
    g = dgl.DGLGraph(g)
  
    g.ndata['init_h'] = torch.tensor(h).float()
    for key in e:
        a,b = key[0],key[1]
        g.edges[a,b].data['w'] = torch.tensor(e[key]).unsqueeze(0).float()
        g.edges[b,a].data['w'] = torch.tensor(e[key]).unsqueeze(0).float()
    return g

def pad_for_graph(gs, length): 
    for i in range(len(gs)):
        if gs[i].number_of_nodes() < length:
            n = length - gs[i].number_of_nodes()
            gs[i].add_nodes(n)
            # gs[i].ndata['init_h'] = torch.cat((gs[i].ndata['init_h'], torch.zeros(n, 21)), dim = 0)
            # It can add all-zero node feature vectors automatically.
    return gs


#-------------------------------Below is for the idea about adding grammar into the model, but experiments show that it not works.-------------------------#

# the grammar
gram = """smiles -> chain
atom -> bracket_atom
atom -> aliphatic_organic
atom -> aromatic_organic
aliphatic_organic -> 'C'
aliphatic_organic -> 'S'
aliphatic_organic -> 'O'
aliphatic_organic -> 'H'
aliphatic_organic -> 'F'
aromatic_organic -> 'c'
aliphatic_organic -> 'N'
aromatic_organic -> 'n'
aliphatic_organic -> 'Cl'
aromatic_organic -> 's'
aliphatic_organic -> 'B'
aliphatic_organic -> 'Br'
aromatic_organic -> 'o'
aliphatic_organic -> 'Li'
aliphatic_organic -> 'Si'
aliphatic_organic -> 'Sc'
aliphatic_organic -> 'I'
aliphatic_organic -> 'P'
aliphatic_organic -> 'Mg'
aliphatic_organic -> 'Se'
aliphatic_organic -> 'Sn'
aliphatic_organic -> 'K'
aliphatic_organic -> 'Zn'
aliphatic_organic -> 'Cu'
aliphatic_organic -> 'Pt'
aliphatic_organic -> 'Fe'   
aliphatic_organic -> 'Pd'
aromatic_organic -> 'p'
aliphatic_organic -> 'Pb'
aromatic_organic -> 'se'
bracket_atom -> '[' BAI ']'
BAI -> isotope symbol BAC
BAI -> symbol BAC
BAI -> isotope symbol
BAI -> symbol
BAC -> chiral BAH
BAC -> BAH
BAC -> chiral
BAH -> hcount BACH
BAH -> BACH
BAH -> hcount
BACH -> charge class
BACH -> charge
BACH -> class
symbol -> aliphatic_organic
symbol -> aromatic_organic
isotope -> DIGIT
isotope -> DIGIT DIGIT
isotope -> DIGIT DIGIT DIGIT
DIGIT -> '1'
DIGIT -> '2'
DIGIT -> '3'
DIGIT -> '4'
DIGIT -> '5'
DIGIT -> '6'
DIGIT -> '7'
DIGIT -> '8'
DIGIT -> '9'
chiral -> '@'
chiral -> '@@'
hcount -> 'H'
hcount -> 'H' DIGIT
charge -> '-'
charge -> '-' DIGIT
charge -> '-' DIGIT DIGIT
charge -> '+'
charge -> '+' DIGIT
charge -> '+' DIGIT DIGIT
bond -> '-'
bond -> '='
bond -> '#'
bond -> '/'
bond -> '\\'
ringbond -> DIGIT
ringbond -> bond DIGIT
branched_atom -> atom
branched_atom -> atom RB
branched_atom -> atom BB
branched_atom -> atom RB BB
RB -> RB ringbond
RB -> ringbond
BB -> BB branch
BB -> branch
branch -> '(' chain ')'
branch -> '(' bond chain ')'
chain -> branched_atom
chain -> chain branched_atom
chain -> chain bond branched_atom
"""



class SMILESGrammer:
    def __init__(self, grammar):
        self.grammar = grammar
        self.init_CFG()
        self.production_and_digit_maps()

    def init_CFG(self):
        self.GCFG = nltk.CFG.fromstring(self.grammar)
        self.start_symbol = self.GCFG.productions()[0].lhs()
        self.parser = nltk.ChartParser(self.GCFG)
        self.vocab = {'<unk>': 0, '<blank>': 1, '<s>': 2, '</s>': 3, '90': 4, '79': 5, '2': 6, '3': 7, '9': 8, '4': 9, '89': 10, '77': 11, '84': 12, 
        '80': 13, '86': 14, '81': 15, '87': 16, '53': 17, '6': 18, '54': 19, '73': 20, '10': 21, '88': 22, '0': 23, '11': 24, '55': 25, '91': 26, '8': 27,
         '1': 28, '34': 29, '36': 30, '85': 31, '48': 32, '44': 33, '64': 34, '12': 35, '.': 36, '72': 37, '39': 38, '40': 39, '56': 40, '83': 41, '62': 42,
          '46': 43, '5': 44, '43': 45, '15': 46, '<RX_1>': 47, '63': 48, '<RX_2>': 49, '74': 50, '49': 51, '13': 52, '82': 53, '66': 54, '<RX_6>': 55, '69': 56,
           '16': 57, '<RX_3>': 58, '57': 59, '75': 60, '<RX_7>': 61, '14': 62, '20': 63, '41': 64, '38': 65, '18': 66, '19': 67, '<RX_9>': 68, '76': 69,
            '<RX_4>': 70, '<RX_8>': 71, '58': 72, '21': 73, '<RX_5>': 74, '78': 75, '22': 76, '24': 77, '<RX_10>': 78, '65': 79, '42': 80, '59': 81, '26': 82,
             '27': 83, '17': 84, '33': 85, '60': 86, '23': 87, '25': 88, '28': 89, '61': 90, '29': 91, '30': 92, '70': 93}
        self.reverse_vocab = {self.vocab[key]:key for key in self.vocab.keys()}

        # keys = list(self.vocab.keys())
        # keys.sort()
        # print(keys)



        lhs_list = []
        all_lhs = [a.lhs().symbol() for a in self.GCFG.productions()]
        for a in all_lhs:
            if a not in lhs_list:
                lhs_list.append(a)
        D = len(self.GCFG.productions())

        self.lhs_list = lhs_list

        # this map tells us the rhs symbol indices for each production rule
        rhs_map = [None]*D
        count = 0
        for a in self.GCFG.productions():
            rhs_map[count] = []
            for b in a.rhs():
                if not isinstance(b,six.string_types):
                    s = b.symbol()
                    rhs_map[count].extend(list(np.where(np.array(lhs_list) == s)[0]))
            count = count + 1

        masks = np.zeros((len(lhs_list),D))
        count = 0

        # this tells us for each lhs symbol which productions rules should be masked
        for sym in lhs_list:
            is_in = np.array([a == sym for a in all_lhs], dtype=int).reshape(1,-1)
            masks[count] = is_in
            count = count + 1

        # this tells us the indices where the masks are equal to 1
        index_array = []
        for i in range(masks.shape[1]):
            index_array.append(np.where(masks[:,i]==1)[0][0])
        ind_of_ind = np.array(index_array)

        max_rhs = max([len(l) for l in rhs_map])

        self.masks = masks
        self.rhs_map = rhs_map
        # print(lhs_list)
        # print(len(lhs_list))    # 22
    
    def production_and_digit_maps(self):
        self.production_digit_map = {str(self.GCFG.productions()[i]):str(i) for i in range(len(self.GCFG.productions()))}
        self.digit_production_map = {str(i) : self.GCFG.productions()[i] for i in range(len(self.GCFG.productions()))}


        
    def seq2grammarseq(self, seq):
    
        parse_tree = next(self.parser.parse(seq[1:]))
        productions = parse_tree.productions()
        
        grammar_seq = [ int(self.production_digit_map[str(pro)]) for pro in productions]
        res_smiles_index = self.digit2smiles(grammar_seq)
        return [grammar_seq, res_smiles_index]



    '''
    Parameters: digits: a string of digits representing a sequence of productions.
    Return: is_valid: True or False; res_smiles: if valid,  return smiles, else return ''. 
    '''
    def digit2smiles(self, digits):
        stack = []
        res_smiles_index =  []
     
        stack.append([self.GCFG.productions()[0].lhs(), 0])

        
        start = 0

        
        while start <= len(digits)-1:
            if len(stack) == 0:
                return []
            top_symbol = stack[-1][0]
            index = stack[-1][1]
            stack.pop()

            if isinstance(top_symbol, str):
                res_smiles_index.append(index)
                #print(top_symbol)
                continue
                
            production = self.digit_production_map[str(digits[start])]
            
            if production.lhs() == top_symbol:
                for i in range(len(production.rhs())-1, -1, -1):
                    stack.append( [production.rhs()[i], start])
            else:
                return []
            start += 1
        for item in list(reversed(stack)):
            res_smiles_index.append(item[1])
    
        return res_smiles_index


    '''
    Parameters: sequence: a sequence of numbers which represent production rules.
    Return: mask vector
    '''
    def sequence2maskvec(self, sequence):
        stack = []

        for i in range(len(sequence)):
            production = self.digit_production_map[sequence[i]]
            if i > 0:
                top_symbol = stack[-1]
                stack.pop()
                assert production.lhs() == top_symbol
            for j in range(len(production.rhs())-1, -1, -1):
                if not isinstance(production.rhs()[j], str):
                    stack.append(production.rhs()[j])

        mask_vec = np.array([-np.inf]*94)
        if len(stack) == 0:    
            mask_vec[[3,36]] = 0 # only .(3) and '</s>(36) are valid'
            return mask_vec
        
        symbol = stack[-1]
        print(stack)
        tmp_mask_vec = self.masks[self.lhs_list.index(symbol.symbol())]
        indexes = np.where(tmp_mask_vec == 1)[0]
        print(indexes)
        valid_indexes = []
        for index in indexes:
            if str(index) in self.vocab:
                valid_indexes.append(self.vocab[str(index)]) 
        mask_vec[valid_indexes] = 0
        return mask_vec, stack


    def update_stack(self, stack, digit):
        flag = False
        try:
            production = self.digit_production_map[self.reverse_vocab[digit]]
        except:
            flag = True
            # production = self.GCFG.productions()[0]
        if flag:
            return stack
        if len(stack) > 0:
            top_symbol = stack[-1]
            stack.pop() 
            assert production.lhs() == top_symbol
        for j in range(len(production.rhs())-1, -1, -1):
            if not isinstance(production.rhs()[j], str):
                stack.append(production.rhs()[j])
        return stack


    def get_maskvec(self, stack, is_begin):
        mask_vec = np.array([-np.inf]*94)
        if len(stack) == 0:    
            if is_begin:
                mask_vec[23] = 0
            else:
                mask_vec[[3,23,36]] = 0 # only .(3) and '</s>(36) are valid'
            return mask_vec.reshape(1,-1)

        symbol = stack[-1]
        tmp_mask_vec = self.masks[self.lhs_list.index(symbol.symbol())]
        indexes = np.where(tmp_mask_vec == 1)[0]
       
        valid_indexes = []
        for index in indexes:
            if str(index) in self.vocab:
                valid_indexes.append(self.vocab[str(index)]) 
        mask_vec[valid_indexes] = 0
        return mask_vec.reshape(1,-1)

    
    def extend_right_stack(self, stacks, indexes):
        res_stacks = []
        for index in indexes:
            res_stacks.append(stacks[index].copy())
        return res_stacks


grammar = SMILESGrammer(gram)


class GramLSTM(nn.Module):
    def __init__(self):
        super(GramLSTM, self).__init__()
        self.embeddings = nn.Embedding(num_embeddings = 93, embedding_dim = 128, padding_idx = 92)
        self.lstm = nn.LSTM(input_size = 128, hidden_size = 256, batch_first = True)
    
    def forward(self, x, data_length):
        x = self.embeddings(x.long().cuda())
        batch_x_pack = rnn_utils.pack_padded_sequence(x,  data_length, batch_first=True)
        output, (h,c) = self.lstm(batch_x_pack)
        out_pad, out_len = rnn_utils.pad_packed_sequence(output, batch_first=True)
        return out_pad


def batch_grammars(grammars):
    input_seqs = [gram[0] for gram in grammars]
    input_indexs = [gram[1] for gram in grammars] 
    
    for i in range(len(input_seqs)):
        input_seqs[i] = torch.tensor(input_seqs[i])
    input_seqs.sort(key=lambda x: len(x), reverse=True)
    data_length = [len(sq) for sq in input_seqs]
    x = rnn_utils.pad_sequence(input_seqs, padding_value = 92, batch_first=True)
    # batch_x_pack = rnn_utils.pack_padded_sequence(x,  data_length, batch_first=True)
    return [x, data_length, input_indexs]
