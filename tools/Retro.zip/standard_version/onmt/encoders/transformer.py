"""
Implementation of "Attention is All You Need"
"""

import torch.nn as nn
from onmt.GCN import *
from onmt.MYGCN import *
import time
import onmt
#from onmt.MPNNs.MPNN import * 
import onmt.myutils as myutils
from onmt.encoders.encoder import EncoderBase
# from onmt.utils.misc import aeq
from onmt.modules.position_ffn import PositionwiseFeedForward
# from onmt.encoders import myutils
# from onmt.encoders.MPNN.MPNN import MPNN
from onmt.GATGATE import *
import torch.nn.utils.rnn as rnn_utils
class TransformerEncoderLayer(nn.Module):
    """
    A single layer of the transformer encoder.

    Args:
        d_model (int): the dimension of keys/values/queries in
                   MultiHeadedAttention, also the input size of
                   the first-layer of the PositionwiseFeedForward.
        heads (int): the number of head for MultiHeadedAttention.
        d_ff (int): the second-layer of the PositionwiseFeedForward.
        dropout (float): dropout probability(0-1.0).
    """

    def __init__(self, d_model, heads, d_ff, dropout):
        super(TransformerEncoderLayer, self).__init__()
        self.self_attn = onmt.modules.MultiHeadedAttention(
            heads, d_model, dropout=dropout)
        self.feed_forward = PositionwiseFeedForward(d_model, d_ff, dropout)
        self.layer_norm = onmt.modules.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, inputs, mask):
        """
        Transformer Encoder Layer definition.

        Args:
            inputs (`FloatTensor`): `[batch_size x src_len x model_dim]`
            mask (`LongTensor`): `[batch_size x src_len x src_len]`

        Returns:
            (`FloatTensor`):

            * outputs `[batch_size x src_len x model_dim]`
        """
        input_norm = self.layer_norm(inputs)
        context, _ = self.self_attn(input_norm, input_norm, input_norm,
                                    mask=mask)
        out = self.dropout(context) + inputs
        return self.feed_forward(out)


class TransformerEncoder(EncoderBase):
    """
    The Transformer encoder from "Attention is All You Need".


    .. mermaid::

       graph BT
          A[input]
          B[multi-head self-attn]
          C[feed forward]
          O[output]
          A --> B
          B --> C
          C --> O

    Args:
        num_layers (int): number of encoder layers
        d_model (int): size of the model
        heads (int): number of heads
        d_ff (int): size of the inner FF layer
        dropout (float): dropout parameters
        embeddings (:obj:`onmt.modules.Embeddings`):
          embeddings to use, should have positional encodings

    Returns:
        (`FloatTensor`, `FloatTensor`):

        * embeddings `[src_len x batch_size x model_dim]`
        * memory_bank `[src_len x batch_size x model_dim]`
    """

    def __init__(self, num_layers, d_model, heads, d_ff,
                 dropout, embeddings):
        super(TransformerEncoder, self).__init__()
        self.num_layers = num_layers
        self.embeddings = embeddings
        self.transformer = nn.ModuleList(
            [TransformerEncoderLayer(d_model, heads, d_ff, dropout)
             for _ in range(num_layers)])
        self.layer_norm = onmt.modules.LayerNorm(d_model)
        #self.gcn = Net()
        self.gcn = GATGATE(29,256,4,2)
        self.fc = nn.Linear(512, 256)
        #self.gramlstm = myutils.GramLSTM()

    def forward(self, src, lengths=None):
        """ See :obj:`EncoderBase.forward()`"""

        gs = src[1]
#        grammars = src[2]
        src = src[0]

        #emb3 = self.gramlstm(grammars[0], grammars[1])
        #emb3 = [emb3[i, idx] for i, idx in enumerate(grammars[2])]
        #emb3 = rnn_utils.pad_sequence(emb3)
        #emb3 = emb3.permute(1,0,2)


        #with_reaction_type = True
        #if with_reaction_type == True:
        #    pad_zero = torch.zeros(emb3.size(0), 1, emb3.size(2)).cuda()
        #    emb3 = torch.cat((pad_zero, emb3), dim = 1)
      
        emb = self.embeddings(src)

        out = emb.transpose(0, 1).contiguous()
        
        emb2 = myutils.gcn_emb(self.gcn, gs, src.device.index)
        emb2 = emb2.view(src.size(1), -1 , 256)
        #is_atom = is_atom.view(src.size(1), -1, 1)
        #out = torch.cat((out, emb2, is_atom), dim = 2)
        out = torch.cat((out, emb2), dim = 2)
        out = self.fc(out)
       
        words = src[:, :, 0].transpose(0, 1)
        w_batch, w_len = words.size()
        padding_idx = self.embeddings.word_padding_idx
        mask = words.data.eq(padding_idx).unsqueeze(1) \
            .expand(w_batch, w_len, w_len)
        # Run the forward pass of every layer of the tranformer.
        
        for i in range(self.num_layers):
            out = self.transformer[i](out, mask)
        out = self.layer_norm(out)
       
        return emb, out.transpose(0, 1).contiguous(), lengths

