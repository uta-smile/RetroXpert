with open('src-train.txt', 'r') as f:
    data = f.readlines()
with open('src-train.txt', 'w') as f:
    for d in data:  
        d = d.strip().split(' ')[1:]
        f.write(' '.join(d) + '\n')



