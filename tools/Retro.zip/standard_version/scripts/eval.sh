python -u score_predictions.py -beam_size 5 -targets data/tgt-test.txt -prediction output/pred.txt
