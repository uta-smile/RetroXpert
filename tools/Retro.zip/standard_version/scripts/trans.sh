export CUDA_VISIBLE_DEVICES=4
nohup python -u translate.py -model experiments/checkpoints/model_step_130000.pt -gpu 0 -src data/src-test.txt -output output/pred.txt -beam_size 5 -n_best 5 -batch_size 64 -replace_unk -max_length 200 -fast > output/trans.out &
