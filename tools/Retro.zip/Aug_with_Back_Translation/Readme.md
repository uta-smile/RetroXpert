# Augment the data by (iterative) back translation

You should tree a Transformer for synthesis first, and then use it to generate some possible target molecules from "src-train.txt" and write them to "pred.txt".

# Run

python augment.py

It will output the augment data, which are chemical valid and different from the ground truths, into "augmentdata/src-train.txt" and "augmentdata/tgt-train.txt". Then, merge it with the original training data as the new training data.

You can set the top-k possible targets as candidates by setting the parameter k in "augment.py".
