import numpy as np
import pandas as pd
from rdkit import Chem
import re
from rdkit.Chem import Draw
from IPython import embed

def augment_data(predfile, truefile, synfile, k):
    with open(predfile, 'r') as f:
        pred = f.readlines()
    with open(truefile, 'r') as f:
        testdata = f.readlines()
    with open(synfile, 'r') as f:
        syndata = f.readlines()
    augment_smiles = []
    augment_syn = []
    for i, truesms in enumerate(testdata):
        for n in range(k):
            if truesms != pred[i*3 + n]:       # the n-th sample
                mol = Chem.MolFromSmiles(''.join(pred[i*3+n].split()))
                if mol is not None:
                    augment_syn.append(syndata[i])
                    augment_smiles.append(pred[i*3+n]) 
    
    with open('augmentdata/src-train.txt', 'w') as f1:
        with open('augmentdata/tgt-train.txt', 'w') as f2:
            for i in range(len(augment_smiles)):
                syn = augment_syn[i].strip().split()
                smiles= augment_smiles[i].strip().split()
                tag = [syn[0]]
                syn = syn[1:]
                smiles = tag + smiles
                f1.write(' '.join(syn))
                f2.write(' '.join(smiles))
                f1.write('\n')
                f2.write('\n')
               
    print('augment data ok!')


# select chemical valid but wrong reactions as augment data, which will be written into augmentdata/ folder. 
augment_data('output/pred.txt', 'nosyndata/tgt-train.txt', 'nosyndata/src-train.txt', 2)    # 2 means top-2
