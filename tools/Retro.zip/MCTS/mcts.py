import numpy as np
import torch
import torch.nn as nn
import copy
import rdkit
from rdkit import Chem
import os
import pickle
import random
from IPython import embed
import sys

sys.path.append("..")
import translate as onmttrans
with open('bbb', 'rb') as f:
    Building_Blocks = pickle.load(f)
Building_Blocks.add('CO')
ATOMS = ['B',
 'Br',
 'C',
 'Cl',
 'Cu',
 'F',
 'Fe',
 'I',
 'K',
 'Li',
 'Mg',
 'N',
 'O',
 'P',
 'Pd',
 'Pt',
 'S',
 'Se',
 'Si',
 'Sn',
 'Zn']

EMB_ATOMS = set(ATOMS+['c',
 'n',
 'o',
 's',
 'se'])

MAX_DEPTH = 5
CONSTANT = 1 / np.sqrt(2)


class Node():

    def __init__(self):
        
        self.bbchems = []
        self.notbbchems = []
        self.V = 0
        self.Q = 0.0

        self.parent = None
        self.children = []
        self.depth = 0
        self.produce_type = 0



    def is_terminal(self):
        # all chems in building_blocks
        # Return is_terminal, which type terminal(True for all in building block, False for reach the max depth)
        
        if len(self.notbbchems) == 0:
            return True, True
        assert self.depth <= MAX_DEPTH
        if self.depth == MAX_DEPTH:
            return True, False
        return False, True      # the second is True or False doesn't matter
    

    
def travel(node, is_train = True):
    # find a leaf node
    if is_train:
        while len(node.children) > 0:
            max_ucb = float("-inf")
            res_node = None
            for child in node.children:
                if child.V == 0:
                    res_node = child
                    break
                UCB = child.Q / child.V + CONSTANT * np.sqrt(2*np.log(node.V) / child.V)
                if UCB > max_ucb:
                    max_ucb = UCB
                    res_node = child
            node = res_node 

        
        is_terminal, all_in_bb = node.is_terminal()

        if is_terminal and all_in_bb:
            print('just backpp 1.0')
            #input()
            backpp(node, 1.0)
        elif is_terminal and not all_in_bb:
            print('just backpp -1.0')
            backpp(node, float(   len(node.bbchems) / (len(node.notbbchems) + len(node.bbchems))  ))
        
        # if has not been visited, sitimulate; else expand and perform travel again

        elif node.V == 0:
            print('begin to rollout')
            #input()
            reward = rollout(node)
            backpp(node, reward)

        else:
            print('beign to expand, then travel')
            #input()
            expand(node)
            travel(node, True)
    else:
        paths = [node]
        while len(node.children) > 0:
            max_ucb = node.children[0].Q 
            res_node = node.children[0]
            for child in node.children:
                UCB = child.Q 
                if UCB > max_ucb:
                    max_ucb = UCB
                    res_node = child
            node = res_node 
            paths.append(node)
        return paths



def rollout(root_node):  
    
    node = copy.deepcopy(root_node)
    while True:
        #embed()
        is_terminal, all_in_bb = node.is_terminal()
        if is_terminal and all_in_bb:
            return 1.0
        elif is_terminal and not all_in_bb:
            return float(   len(node.bbchems) / (len(node.notbbchems) + len(node.bbchems))  )
        else:
            pop_idx = random.randint(0, len(node.notbbchems)-1)
            target_chem = node.notbbchems[pop_idx]
            predict_smiles, scores = translate(target_chem, is_rollout = True) # only top-1 use the scoring function
            predict_smiles, _ = keep_valid(predict_smiles, True)
            predict_smiles = select_best(target_chem, predict_smiles, scores)
            if predict_smiles == "":
                return float(   len(node.bbchems) / (len(node.notbbchems) + len(node.bbchems))  )
            smiles = predict_smiles.strip().split('.')
            new_node = Node()
            new_node.depth = node.depth + 1
            new_node.notbbchems = node.notbbchems.copy()
            del new_node.notbbchems[pop_idx]
            new_node.bbchems = node.bbchems.copy()
            #embed()
            for ss in smiles:
                if ss in Building_Blocks or not is_organic(ss):
                    new_node.bbchems.append(ss)
                else:
                    new_node.notbbchems.append(ss)
            
            node = new_node
        


def backpp(node, reward):
    while node != None:
        node.V += 1
        node.Q += reward
        node = node.parent



def expand(node):
    pop_idx = random.randint(0, len(node.notbbchems)-1)
    target_chem = node.notbbchems[pop_idx]
    predicted_smiles = translate(target_chem)   # top-5, 10 reaction types, total 50 candidates


    valid_smiles, type_list = keep_valid(predicted_smiles, is_rollout = False) # keep valid smiles, less than 50
    # print('valid', len(valid_smiles))
    # input()
    for i, smiles in enumerate(valid_smiles):
        new_node = Node()
        new_node.parent = node
        new_node.depth = node.depth + 1
        new_node.produce_type = type_list[i]
        new_node.notbbchems = node.notbbchems.copy()
        del new_node.notbbchems[pop_idx]
        new_node.bbchems = node.bbchems.copy()
        smiles = smiles.split('.')

        for ss in smiles:
            if ss in Building_Blocks or not is_organic(ss):
                new_node.bbchems.append(ss)
            else:
                new_node.notbbchems.append(ss)
        node.children.append(new_node)


def keep_valid(smiles, is_rollout):
    valid_smiles = []
    type_list= []

    for i, ss in enumerate(smiles):
        chemical = Chem.MolFromSmiles(ss)
        if chemical != None and len(chemical.GetAtoms())>=2:
            valid_smiles.append(ss)
            if not is_rollout:
                reaction_type = int((i+1)/3)
                if (i+1)%3 != 0:
                    reaction_type += 1
                type_list.append(reaction_type)
    return valid_smiles, type_list


def is_organic(smiles):
    num = 0
    organic_flag = False
    for i in range(len(smiles)):
        if smiles[i] in EMB_ATOMS:
            num += 1
        if smiles[i] == 'C' or smiles[i] == 'c':
            organic_flag = True
        if num >= 2 and organic_flag:
            break
    return num>=2 and organic_flag



def select_best(raw_smiles, predicted_smiles, scores):
    res_smiles = ""
    max_val = float("-inf")
    a, b = 100, 6
    for i, smiles in enumerate(predicted_smiles):
        mol_raw = Chem.MolFromSmiles(raw_smiles)
        mol_cur = Chem.MolFromSmiles(smiles)
        val = a * np.exp(np.exp(scores[i])) - b * abs(Chem.rdMolDescriptors.CalcNumRings(mol_raw) - Chem.rdMolDescriptors.CalcNumRings(mol_cur)) -  abs(len(raw_smiles) - len(smiles))
        if val > max_val:
            res_smiles = smiles
            max_val = val
    # assert res_smiles != ""
    return res_smiles





def translate(smiles, is_rollout = False):

    # prepare data
    src_data = []
    with open('src.txt', 'w') as f:
        prefix = "<RX_"
        for i in range(1, 11):
            # preprocess the smiles for translate (tokenize)
            res_smiles = []
            start = 0
            while start <= len(smiles)-2:
                if (smiles[start] + smiles[start+1]) in EMB_ATOMS:
                    res_smiles.append(smiles[start] + smiles[start+1])
                    start += 2
                else:
                    res_smiles.append(smiles[start])
                    start += 1
            while start < len(smiles):
                res_smiles.append(smiles[start])
                start += 1
            res_smiles = " ".join(res_smiles)

            f.write(prefix + str(i) + "> " + res_smiles + '\n')

    if is_rollout:
    
        params = {'src':'src.txt', 'model':'../experiments/checkpoints2/model_step_500000.pt', 'gpu':0, 'output':'pred.txt', 'beam_size':1, 'n_best':1, 'batch_size': 10, 'max_length':200}
        all_scores, all_predictions = onmttrans.model_translate(params)
        
    else:
        params = {'src':'src.txt', 'model':'../experiments/checkpoints2/model_step_500000.pt', 'gpu':0, 'output':'pred.txt', 'beam_size':3, 'n_best':3, 'batch_size': 10, 'max_length':200}
        all_scores, all_predictions = onmttrans.model_translate(params)
   
    res_all = []
    for pre in all_predictions:
        for smiles in pre:
            res_all.append(''.join(smiles.strip().split(' ')))
    
    res_score = []
    for score in all_scores:
        res_score.extend(score)
    if is_rollout:
        return res_all, res_score
    return res_all



def monte_carlo_tree_search(node):

    # train
    NUM_ITER = 20

    expand(node)

    for i in range(NUM_ITER):
        print('The ' + str(i) + '-th iteration')
        travel(node)
        #embed() 
        #if i % 20 == 0:
        #    paths = travel(node, False) 
        #    input()
        
    with open('node', 'wb') as f:
        pickle.dump(node, f)
    print('okkkkkkkkkkkkkkkkkkkkkk')

node = Node()
#mol_s = "C O C 1 = C ( O C ) C ( = O ) C ( C c 2 c c c c ( C ( = O ) N c 3 c c c n c 3 ) c 2 O ) = C ( C ) C 1 = O"
mol_s = "C C ( C ) ( C ) O C ( = O ) N 1 C C N ( C ( = O ) c 2 c c ( C O S ( C ) ( = O ) = O ) c c c 2 F ) C C 1"
node.notbbchems.append(''.join(mol_s.split()))
print(node.notbbchems)
monte_carlo_tree_search(node)
