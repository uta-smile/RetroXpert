import pickle
from Node import *
from IPython import embed

with open('node', 'rb') as f:
    node = pickle.load(f)

def printnode(node):
    print('notbbchems', node.notbbchems)
    print('bbchems', node.bbchems)


def printchildrenscore(node):
    for child in node.children:
        print(child.Q, end = " ")
    print('\n')
#printnode(node)

def find(node):
    if len(node.bbchems) > 0 and len(node.notbbchems) == 0:
        print('find one', node.bbchems)
        tmp_node = node
        while tmp_node.parent != None:
            printnode(tmp_node.parent)
            tmp_node = tmp_node.parent
        input()
    for child in node.children:
        find(child)



while len(node.children) > 0:
    max_ucb = node.children[0].Q 
    res_node = node.children[0]
    printchildrenscore(node)
    for i, child in enumerate(node.children):
        UCB = child.Q 
        if UCB > max_ucb:
            max_ucb = UCB
            res_node = child
    node = res_node
    printnode(node) 
    
