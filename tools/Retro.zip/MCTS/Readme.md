# Multi-step Retrosynthesis with Transformer and MCTS

## Introduction
1. "bbb" is the building block
2. "mcts.py" contains the main functions of our MCTS.
3. "src.txt" and "pred.txt" are intermidiate files.

# Run
To run the MCTS:
1. prepare a trained model in "experiments/checkpoints"
2. Move this "MCTS" folder into "standard_version" folder, and replace the "standard_version/translate.py" with "MCTS/translate.py"
3. write your target molecule's SMILES as mol_s, set the number of iteration in "mcts.py". Then do "python mcts.py". This will output a "Node" object which is the root node the MCTS search tree.

For a Node object, its "bbchem" contains molecules in bbb, and its "notbbchem" contains the molecules not in bbb.



# Test
python test.py
This will output the retrosynthesis route (from the root to the leaf) as:
node1 bbchems notbbchems
node2 bbchems notbbchems
...
