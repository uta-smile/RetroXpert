class Node():

    def __init__(self):
        
        self.bbchems = []
        self.notbbchems = []
        self.V = 0
        self.Q = 0.0

        self.parent = None
        self.children = []
        self.depth = 0
        self.produce_type = 0



    def is_terminal(self):
        # all chems in building_blocks
        # Return is_terminal, which type terminal(True for all in building block, False for reach the max depth)
        
        if len(self.notbbchems) == 0:
            return True, True
        assert self.depth <= MAX_DEPTH
        if self.depth == MAX_DEPTH:
            return True, False
        return False, True      # the second is True or False doesn't matter
    
